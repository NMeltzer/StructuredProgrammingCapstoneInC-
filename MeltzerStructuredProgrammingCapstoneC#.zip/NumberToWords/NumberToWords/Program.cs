﻿using System;

namespace NumberToWords
{
    class Program
    {
        static void Main(string[] args)
        {
            new ConvertNumbersToWords();
        }
    }
}
