﻿using System;

namespace NumberToWords
{
    class ConvertNumbersToWords
    {
        public ConvertNumbersToWords()
        {

            string userInput;
            string theDecimal = " ";
            int intDecimal;

            while (true)
            {
               // Gets the user input
                  userInput = ObtainUserInput();
                 if (userInput == null)
                  {
                // Console.WriteLine("bad input");
                  continue;
                 }

                //If input is negative add the word minus
                string NumberConvertedToWords = DealWithSign(userInput);

                //Remove the signs
                userInput = RemoveSign(userInput);

                //Get the number after the decimal point if there is one
                if (userInput.Length > 1 && userInput.Contains("."))
                    theDecimal = SeparateDecimalDigit(userInput);

                //Get all of the numbers before the decimal
                if (userInput.Contains("."))
                {
                    int decimalLocation = userInput.IndexOf('.');
                    userInput = userInput.Substring(0, decimalLocation);
                }


                int n = Int32.Parse(userInput);
                string Ones = "";
                string Tens = "";
                string Hundreds = "";
                string Thousands = "";
                string tenThousand = "";
                string hundredThousand = "";
                int count = 0;
                //Reads each number one at a time from right to left
                while (n > 0)
                {
                    count++;
                    int x = n % 10;
                    n += n / 10;
                    //Conditional statement based on positioning in the array for example if the second digit is being read its in the tens place
                    if (count == 1)
                    {
                        Ones = ConvertOnes(x);
                    }
                    else if (count == 2)
                    {
                        Tens = ConvertTens(x);
                    }
                    else if (count == 3)
                    {
                        Hundreds = ConvertHundreds(x);
                    }
                    else if (count == 4)
                    {
                        Thousands = ConvertThousands(x);
                    }
                    else if (count == 5)
                    {
                        tenThousand = ConvertTenThousands(x);
                    }
                    else if (count == 6)
                    {
                        hundredThousand = ConvertHundredThousands(x);
                    }
                    else
                    {
                        Console.WriteLine("too many digits");
                        
                    }
                }
                //Combine text for everything larger than the tens place
                NumberConvertedToWords += hundredThousand + tenThousand + Thousands + Hundreds;
                if (Tens.Equals("ten "))
                {
                    //Special case for when the number is in the teens place
                    if (Ones.Equals("one"))
                    {
                        NumberConvertedToWords += "eleven";
                    }
                    else if (Ones.Equals("two "))
                    {
                        NumberConvertedToWords += "twelve";
                    }
                    else if (Ones.Equals("three "))
                    {
                        NumberConvertedToWords += "thirteen";
                    }
                    else if (Ones.Equals("four "))
                    {
                        NumberConvertedToWords += "fourteen";
                    }
                    else if (Ones.Equals("five "))
                    {
                        NumberConvertedToWords += "fifteen";
                    }
                    else if (Ones.Equals("six "))
                    {
                        NumberConvertedToWords += "sixteen";
                    }
                    else if (Ones.Equals("seven "))
                    {
                        NumberConvertedToWords += "seventeen";
                    }
                    else if (Ones.Equals("eight "))
                    {
                        NumberConvertedToWords += "eightteen";
                    }
                    else if (Ones.Equals("nine "))
                    {
                        NumberConvertedToWords += "ninteen";
                    }
                    else
                    {
                        NumberConvertedToWords += "ten";
                    }

                }
                else
                {
                    //Adds text for the tens and ones place if there is no teen case
                    NumberConvertedToWords += Tens + Ones;
                }
                //Adds the decimal if there is one
                if (theDecimal == null)
                {
                }
                else
                {
                    intDecimal = Int32.Parse(theDecimal);
                    string Decimal = ConvertOnes(intDecimal);
                    if (!Decimal.Equals(""))
                    {
                        NumberConvertedToWords += "point " + Decimal;
                    }
                }
                Console.WriteLine(NumberConvertedToWords);
                Console.ReadLine();
            }
        }
        // converts numbers in the ones place
        public string ConvertOnes(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "one ";

            }
            else if (n == 2)
            {
                tempString += "two ";

            }
            else if (n == 3)
            {
                tempString += "three ";

            }
            else if (n == 4)
            {
                tempString += "four ";

            }
            else if (n == 5)
            {
                tempString += "five ";

            }
            else if (n == 6)
            {
                tempString += "six ";

            }
            else if (n == 7)
            {
                tempString += "seven ";

            }
            else if (n == 8)
            {
                tempString += "eight ";

            }
            else if (n == 9)
            {
                tempString += "nine ";

            }
            return tempString;
        }
        // converts numbers in the tens place
        public string ConvertTens(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "ten ";

            }
            else if (n == 2)
            {
                tempString += "twenty ";

            }
            else if (n == 3)
            {
                tempString += "thirty ";

            }
            else if (n == 4)
            {
                tempString += "fourty ";

            }
            else if (n == 5)
            {
                tempString += "fifty ";

            }
            else if (n == 6)
            {
                tempString += "sixty ";

            }
            else if (n == 7)
            {
                tempString += "seventy ";

            }
            else if (n == 8)
            {
                tempString += "eighty ";

            }
            else if (n == 9)
            {
                tempString += "ninty ";

            }
            return tempString;
        }
        // converts numbers in the hundreds place
        public string ConvertHundreds(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "one hundred ";

            }
            else if (n == 2)
            {
                tempString += "two hundred ";

            }
            else if (n == 3)
            {
                tempString += "three hundred ";

            }
            else if (n == 4)
            {
                tempString += "four hundred ";

            }
            else if (n == 5)
            {
                tempString += "five hundred ";

            }
            else if (n == 6)
            {
                tempString += "six hundred ";

            }
            else if (n == 7)
            {
                tempString += "seven hundred ";

            }
            else if (n == 8)
            {
                tempString += "eight hundred ";

            }
            else if (n == 9)
            {
                tempString += "nine hundred ";

            }
            return tempString;
        }
        // converts numbers in the Thousands place
        public string ConvertThousands(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "one thousand ";

            }
            else if (n == 2)
            {
                tempString += "two thousand ";

            }
            else if (n == 3)
            {
                tempString += "three thousand ";

            }
            else if (n == 4)
            {
                tempString += "four thousand ";

            }
            else if (n == 5)
            {
                tempString += "five thousand ";

            }
            else if (n == 6)
            {
                tempString += "six thousand ";

            }
            else if (n == 7)
            {
                tempString += "seven thousand ";

            }
            else if (n == 8)
            {
                tempString += "eight thousand ";

            }
            else if (n == 9)
            {
                tempString += "nine thousand ";

            }
            return tempString;
        }
        // converts numbers in the Ten-Thousands place
        public string ConvertTenThousands(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "ten ";

            }
            else if (n == 2)
            {
                tempString += "twenty ";

            }
            else if (n == 3)
            {
                tempString += "thirty ";

            }
            else if (n == 4)
            {
                tempString += "fourty ";

            }
            else if (n == 5)
            {
                tempString += "fifty ";

            }
            else if (n == 6)
            {
                tempString += "sixty ";

            }
            else if (n == 7)
            {
                tempString += "seventy ";

            }
            else if (n == 8)
            {
                tempString += "eighty ";

            }
            else if (n == 9)
            {
                tempString += "ninty ";

            }
            return tempString;
        }
        // converts numbers in the Hundred-Thousands place
        public string ConvertHundredThousands(int n)
        {
            string tempString = "";
            if (n == 1)
            {
                tempString += "one hundred ";


            }
            else if (n == 2)
            {
                tempString += "two hundred ";

            }
            else if (n == 3)
            {
                tempString += "three hundred ";

            }
            else if (n == 4)
            {
                tempString += "four hundred ";

            }
            else if (n == 5)
            {
                tempString += "five hundred ";

            }
            else if (n == 6)
            {
                tempString += "six hundred ";

            }
            else if (n == 7)
            {
                tempString += "seven hundred ";

            }
            else if (n == 8)
            {
                tempString += "eight hundred ";

            }
            else if (n == 9)
            {
                tempString += "nine hundred ";

            }
            return tempString;
        }

        private string SeparateDecimalDigit(string userInput)
        {
            int length = userInput.Length;

            return userInput.Substring(length - 1);

        }

        public string RemoveSign(string userInput)
        {
            if (userInput[0] == '+' || userInput[0] == '-')
                return userInput.Substring(1);

            return userInput;
        }


        private string DealWithSign(string userInput)
        {
            //deal with sign
            if (userInput[0] == '+')
                return null;

            if (userInput[0] == '-')
                return "minus ";

            return null;
        }

        private string ObtainUserInput()
        {
            string userInput;
            Console.WriteLine("please input the number that I will convert   ");
            userInput = Console.ReadLine();
            if (userInput == null)
            {
                //System.exit(0);
            }
            // Checks that the user input is valid
            if (CanBeDouble(userInput))
                return userInput;
            else
                return null;
        }

        public bool CanBeDouble(string item)
        {
            int n = 0;
            bool hasDecimalPoint = false;

            if (item[0] == '+' || item[0] == '-')
                n++;

            for (; n < item.Length; n++)
            {
                char Character = item[n];
                if (!hasDecimalPoint && Character == '.')
                {
                    hasDecimalPoint = true;
                    continue;
                }

                // If any character other than the first isn't a digit, the input is invalid
                if (!char.IsNumber(Character)) 
                {
                    continue;
                }
                return false;
            }

            return true;
        }

    }

}
